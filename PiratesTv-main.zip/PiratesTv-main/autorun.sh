#!/bin/bash
python generate_playlist.py
